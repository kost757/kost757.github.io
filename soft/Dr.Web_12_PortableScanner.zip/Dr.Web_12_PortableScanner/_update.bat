@echo off>nul 2>&1
title Update Dr.Web Scanner
echo Dr.Web Scanner
echo �஢�ઠ ����㯭��� ���୥�...
"%~dp0prog\wget.exe" -q -Onul http://google.com || (echo  ��� ����㯠 � ���୥�� & goto END)
echo ����������...
taskkill /f /t /im dwscanner.exe>nul 2>&1
taskkill /f /t /im dwengine.exe>nul 2>&1
if not exist "%~dp0drweb" md "%~dp0drweb"
if not exist "%~dp0drweb\drweb32.key" copy /y "%~dp0prog\drweb32.key" "%~dp0drweb\" > nul
"%~dp0prog\wget.exe" -q --show-progress=off -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/revision.xml" -P "%~dp0prog"
if not exist "%~dp0prog\revision.xml" exit /b
setlocal enabledelayedexpansion
FOR /F "tokens=2-7 delims== " %%a in ('findstr /C:"lzma" "%~dp0prog\revision.xml"') do (
if %%a==name set nam=%%b
if %%c==name set nam=%%d
if %%e==name set nam=%%f
if %%a==hash set has=%%b
if %%c==hash set has=%%d
if %%e==hash set has=%%f
set tmpr=!nam:~8,-1!
findstr /C:"!has!" "%~dp0prog\revision.xml">nul||echo !tmpr!
)>>"%~dp0prog\bases.lst"
FOR /F "tokens=2-7 delims== " %%a in ('findstr /C:"lzma" "%~dp0prog\revision.xml"') do (
if %%c==name set nam=%%d
set tmpr=!nam:~8,-6!
echo !tmpr!
)>>"%~dp0prog\bases2.txt"
dir /B "%~dp0drweb\">"%~dp0prog\bases.txt"
for /f %%a in ('Type "%~dp0prog\bases2.txt"') Do (
(Find /i "%%a" "%~dp0prog\bases.txt" > nul)||Echo %%a.lzma 1>>"%~dp0prog\temp.lst")
type "%~dp0prog\temp.lst" | findstr /i /v "fingerprint" > "%~dp0prog\bases.lst"
del /Q "%~dp0prog\bases.txt" "%~dp0prog\bases2.txt" "%~dp0prog\temp.lst"
ENDLOCAL
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 -i "%~dp0prog\bases.lst" -B "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scanner-gui-console/9/common/dwscanner.exe.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/common/dwengine.exe.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x64/win/nt/common/dwarkdaemon.exe.lzma" -P "%~dp0drweb\x64"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x64/win/nt/common/dwarkapi.dll.lzma" -P "%~dp0drweb\x64"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x64/win/nt/common/dwseapi.dll.lzma" -P "%~dp0drweb\x64"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x86/win/nt/common/dwarkdaemon.exe.lzma" -P "%~dp0drweb\x86"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x86/win/nt/common/dwarkapi.dll.lzma" -P "%~dp0drweb\x86"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1210/windows/90/scan-engine/9/x86/win/nt/common/dwseapi.dll.lzma" -P "%~dp0drweb\x86"

"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/drwtoday.vdb.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/dwmtoday.vdb.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/dwntoday.vdb.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/dwrtoday.vdb.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/drwdaily.vdb.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/drwbase.db.lzma" -P "%~dp0drweb"
"%~dp0prog\wget.exe" -q --show-progress=on -N --tries=1 "http://update.geo.drweb.com/xmlzone/release/1220/windows/90/av-engine/9/common/drweb32.dll.lzma" -P "%~dp0drweb"

IF EXIST "%ProgramFiles(x86)%" (
  "%~dp0\prog\7zr.exe" e -y "%~dp0drweb\x64\*.lzma" -o"%~dp0drweb" > nul
) Else (
  "%~dp0\prog\7zr.exe" e -y "%~dp0drweb\x86\*.lzma" -o"%~dp0drweb" > nul
)
if exist "%~dp0drweb\*.lzma" "%~dp0\prog\7zr.exe" e -y "%~dp0drweb\*.lzma" -o"%~dp0drweb" > nul
ATTRIB +H /S "%~dp0drweb\dw*.exe.lzma"
ATTRIB +H /S "%~dp0drweb\*today.vdb.lzma"
ATTRIB +H /S "%~dp0drweb\drwdaily.vdb.lzma"
ATTRIB +H /S "%~dp0drweb\drwbase.db.lzma"
ATTRIB +H /S "%~dp0drweb\drweb32.dll.lzma"
type nul > "%~dp0drweb\null.lzma"
del /Q "%~dp0drweb\*.lzma" "%~dp0prog\bases.lst" "%~dp0prog\revision.xml"> nul
ATTRIB -H /S "%~dp0drweb\dw*.exe.lzma"
ATTRIB -H /S "%~dp0drweb\*today.vdb.lzma"
ATTRIB -H /S "%~dp0drweb\drwdaily.vdb.lzma"
ATTRIB -H /S "%~dp0drweb\drwbase.db.lzma"
ATTRIB -H /S "%~dp0drweb\drweb32.dll.lzma"
:END