@echo off
net start >"%~dp0Proba2.VqG"
find /i "DrWebEngine"<"%~dp0Proba2.VqG"
if not errorlevel 1 goto ProbaaoAO
IF EXIST "%ProgramFiles(x86)%" (
  "%~dp07zr.exe" e -y "%~dp0..\drweb\x64\*.lzma" -o"%~dp0..\drweb" > nul
) Else (
  "%~dp07zr.exe" e -y "%~dp0..\drweb\x86\*.lzma" -o"%~dp0..\drweb" > nul
)
"%~dp0..\Scanner.exe" -r "%~dp0..\drweb\dwengine.exe" -p "-cons -dll-path=:s:%~dp0..\drweb:s: -vdb-path=:s:%~dp0..\drweb:s:" --hide
:ProbaaoAO
find /i "DrWebEngine"<"%~dp0Proba2.VqG"
if not errorlevel 1 goto ProbaaoAO2
:ProbaaoAO2
ping -n 1 localhost
"%~dp0..\drweb\dwscanner.exe" "%~1"
ping -n 1 localhost
taskkill /f /t /im dwengine.exe
del "%~dp0Proba2.VqG"